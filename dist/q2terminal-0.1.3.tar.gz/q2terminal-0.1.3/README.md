# Interaction with a terminal session

```
```
